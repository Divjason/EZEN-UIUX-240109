import React from "react";

const Tv = () => {
  return (
    <div style={{ backgroundColor: "whitesmoke", height: "200vh" }}>Tv</div>
  );
};

export default Tv;
