import React from "react";
import styled from "styled-components";
import "./App.css";
import Title from "./components/Title";
import TodoItem from "./components/TodoItem";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: #eee;
`;

const TodoList = styled.div`
  display: flex;
  flex-direction: column;
`;

function App() {
  return (
    <Container>
      <Title label="할 일 목록" />
      <TodoList>
        <TodoItem label="React 공부하기" />
        <TodoItem label="TypeScript 공부하기" />
        <TodoItem label="운동하기" />
      </TodoList>
    </Container>
  );
}

export default App;
