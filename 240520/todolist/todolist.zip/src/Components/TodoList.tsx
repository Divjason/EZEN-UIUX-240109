import React from "react";
import { useRecoilValue } from "recoil";
import { toDoState, toDoSelector } from "./atoms";
import CreateTodo from "./CreateTodo";
import Todo from "./Todo";

const TodoList = () => {
  const toDos = useRecoilValue(toDoState);
  const [todo, doing, done] = useRecoilValue(toDoSelector);
  const onInput = (event: React.FormEvent<HTMLSelectElement>) => {
    console.log(event.currentTarget.value);
  };
  return (
    <div>
      <h1>Todo's</h1>
      <hr />
      <select onInput={onInput}>
        <option value="TO_DO">ToDo</option>
        <option value="DOING">Doing</option>
        <option value="DONE">Done</option>
      </select>
    </div>
  );
};

export default TodoList;
