const fakeUser = {
  username: "David",
  loggedIn: true,
};

export const trending = (req, res) => {
  return res.render("home", {
    pageTitle: "Home",
    home: "Home",
    fakeUser: fakeUser,
  });
};

export const see = (req, res) => {
  return res.render("watch");
};

export const edit = (req, res) => {
  console.log(req.params);
  return res.render("edit");
};

export const search = (req, res) => {
  return res.send("Search");
};

export const upload = (req, res) => {
  return res.send("Upload");
};

export const deleteVideo = (req, res) => {
  return res.send("Delete Video");
};
