import React from "react";

const Movies = () => {
  return <div>Movies</div>;
};

export default Movies;
